class World {
  constructor(x, y, width, height) {
    //position, size and hitbox for square objects
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }
}